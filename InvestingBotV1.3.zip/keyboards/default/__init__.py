from .start_button import start_button, cancel_button, language_buttons, language_buttons_continue
from .choise_information_from_tiker_button import choise
