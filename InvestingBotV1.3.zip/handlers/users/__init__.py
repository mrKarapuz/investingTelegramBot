from .help import dp
from .start import dp
from .information_from_ticker import dp
from .comparison import dp
from .select_companies import dp
from .admin import dp
# from .echo import dp

__all__ = ["dp"]
